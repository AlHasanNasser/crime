from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import status
from threading import Thread
from deepface import DeepFace
import numpy as np
from .serializers import ImageSerializerTwo
from PIL import Image
def find_cosine_distance(source_representation: np.ndarray, test_representation: np.ndarray):
    a = np.matmul(np.transpose(source_representation), test_representation)
    b = np.sum(np.multiply(source_representation, source_representation))
    c = np.sum(np.multiply(test_representation, test_representation))
    return 1 - (a / (np.sqrt(b) * np.sqrt(c)))
def get_face(filename): #This function is responsible for returning the face from the database
    image = Image.open(filename) # open the image
    image = image.convert('RGB') #Convert it to RGB
    face_array = np.asarray(image) #convert it to array
    return face_array # return the face array

@api_view(['POST'])
def FaceCompare(request):
    print(request.data)
    serializer = ImageSerializerTwo(data=request.data)
    if serializer.is_valid():
        image1 = serializer.validated_data['image1']
        image2 = serializer.validated_data['image2']

        result_data = {}
        error_data = []

        # Process image and handle potential errors
        def process_image(image, key):
            try:
                face = get_face(image)
                if face is None:
                    raise ValueError(f'No Face Detected in {key}.')
                face = np.array(face) if isinstance(face, tuple) else np.copy(face)
                embedding_objs = DeepFace.represent(face, detector_backend='mtcnn', model_name="Facenet512")
                result_data[key] = np.array(embedding_objs[0]['embedding']) if isinstance(embedding_objs[0], dict) else embedding_objs[0]
            except Exception as e:
                error_data.append(f'Error processing {key}: {str(e)}')

        process_image(image1, 'face1')
        process_image(image2, 'face2')

        # Return error if any face detection fails
        if error_data:
            return Response({'message': ' '.join(error_data), 'score': None}, status=status.HTTP_400_BAD_REQUEST)

        face1 = result_data.get('face1')
        face2 = result_data.get('face2')

        if face1 is None or face2 is None:
            return Response({'message': 'Face detection failed', 'score': None}, status=status.HTTP_400_BAD_REQUEST)

        try:
            cosine_similarity = find_cosine_distance(face1, face2)
        except TypeError as e:
            return Response({'message': str(e), 'score': None}, status=status.HTTP_400_BAD_REQUEST)

        message = 'Face Matched' if cosine_similarity <= 0.5 else 'Face Not Matched'

        return Response({
            'message': message,
            'score': round(cosine_similarity, 2)
        }, status=status.HTTP_200_OK)

    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
