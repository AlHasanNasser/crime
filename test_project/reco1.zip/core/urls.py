from django.urls import path
from . import views

urlpatterns = [
    path('face_verify/', views.FaceCompare),
]